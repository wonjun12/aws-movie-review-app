import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='wonjun159',
    application_name='aws-movie-review-app',
    app_uid='2jkPr21hY0FxKd3fg5',
    org_uid='d1bf8de0-3530-4771-8713-99bd4eb7e2e8',
    deployment_uid='2000a67d-5f02-4120-a8e7-5d3c7fb77d4e',
    service_name='aws-movie-review-app',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.3',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-movie-review-app-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
